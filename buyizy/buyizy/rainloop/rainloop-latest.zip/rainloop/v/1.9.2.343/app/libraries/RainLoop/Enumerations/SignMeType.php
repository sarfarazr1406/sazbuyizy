<?php

namespace RainLoop\Enumerations;

class SignMeType
{
	const DEFAILT_OFF = 'DefaultOff';
	const DEFAILT_ON = 'DefaultOn';
	const UNUSED = 'Unused';
}